package com.yash.springioc5;

public class Supervisor implements Employee{

	public void show() {
		// TODO Auto-generated method stub
		System.out.println("I am Supervisor");
	}

}
