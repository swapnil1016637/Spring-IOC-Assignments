package com.yash.springioc5;

public class Manager implements Employee{

	public void show() {
		// TODO Auto-generated method stub
		System.out.println("I am Manager");
	}

}
