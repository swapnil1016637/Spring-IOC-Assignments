package com.yash.springioc5;

public class EmployeeFactory {
	
	public static Employee getEmployee() {
		//return new Clerk();
		return new Manager();
		//return new Supervisor();
	}

}
