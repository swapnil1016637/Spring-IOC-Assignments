package com.yash.springioc2;

public abstract class Shape {
	
	public abstract void draw();

}
