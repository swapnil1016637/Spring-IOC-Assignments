package com.yash.springioc2;

public class Triangle extends Shape {

	private double height;
	private double base;

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public Triangle(double height, double base) {
		super();
		this.height = height;
		this.base = base;
	}

	@Override
	public String toString() {
		return "Triangle [height=" + height + ", base=" + base + "]";
	}

	public Triangle() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub

		double areaOfTriangle = (base * height) / 2;
		System.out.println("Area Of Triangle: " + areaOfTriangle);

	}

}
