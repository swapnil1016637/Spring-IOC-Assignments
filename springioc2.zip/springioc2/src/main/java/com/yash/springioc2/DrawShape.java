package com.yash.springioc2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawShape {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		Rectangle rect = (Rectangle) context.getBean("rectangle");
		rect.draw();
		Triangle tri = (Triangle) context.getBean("triangle");
		tri.draw();
		Parallelogram par = (Parallelogram) context.getBean("parallelogram");
		par.draw();
	}

}
