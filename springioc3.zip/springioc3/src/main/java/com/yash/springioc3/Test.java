package com.yash.springioc3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		ConstructorMessage message = (ConstructorMessage) context.getBean("message");
		message.show();
	}

}
