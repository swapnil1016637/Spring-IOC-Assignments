package com.yash.springioc;

import java.util.List;

public class City {

	private List<String> cityName;
	private CinemaHall cinemaHall;

	public List<String> getCityName() {
		return cityName;
	}

	public void setCityName(List<String> cityName) {
		this.cityName = cityName;
	}

	public CinemaHall getCinemaHall() {
		return cinemaHall;
	}

	public void setCinemaHall(CinemaHall cinemaHall) {
		this.cinemaHall = cinemaHall;
	}

	public City(List<String> cityName, CinemaHall cinemaHall) {
		super();
		this.cityName = cityName;
		this.cinemaHall = cinemaHall;
	}

	@Override
	public String toString() {
		return "City [cityName=" + cityName + ", cinemaHall=" + cinemaHall + "]";
	}

	public City() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void show() {
		for (String s : cityName) {
			System.out.println("City Name: " + s + "\n");
			cinemaHall.display();

		}
	}

}
